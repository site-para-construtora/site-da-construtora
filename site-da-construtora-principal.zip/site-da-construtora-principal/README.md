# site-da-construtora
repositorio principal

VITOR: ficara responsável pela ortografia do site, seguindo a norma dos nossos padrões

GABRIEL: ficará com a parte de imagens do site e interações com o joão

JOÃO: Carrosséis e interagíveis do site

LUKINHAS e CELSO: cuidará da estética e estilização do site, e fará testes para erros

LUCAS EDUARDO: Ficará responsável pelo footer e o header das páginas, com os botões e informações necessárias, porém a parte de interação fica para a dupla.

Yago e Viny: parte de testes dos códigos e eficiência, buscando versalidade do site e funcionamento, ideias diferentes etc, também ajudaremos a quem precisar e no que precisar
